const circle = document.getElementById("cursor");
    document.addEventListener("mousemove", function(event) {
      circle.style.left = event.clientX + "px";
      circle.style.top = event.clientY + "px";
    });